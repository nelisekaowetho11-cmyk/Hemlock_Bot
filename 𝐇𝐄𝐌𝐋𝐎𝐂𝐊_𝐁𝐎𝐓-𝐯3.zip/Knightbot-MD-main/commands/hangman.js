const fs = require('fs');

const words = ['javascript', 'bot', 'hangman', 'whatsapp', 'nodejs'];
let hangmanGames = {};

function startHangman(sock, chatId) {
    const word = words[Math.floor(Math.random() * words.length)];
    const maskedWord = '_ '.repeat(word.length).trim();

    hangmanGames[chatId] = {
        word,
        maskedWord: maskedWord.split(' '),
        guessedLetters: [],
        wrongGuesses: 0,
        maxWrongGuesses: 6,
    };

    sock.sendMessage(chatId, { text: `𝐆𝐚𝐦𝐞 𝐡𝐚𝐬 𝐛𝐞𝐠𝐢𝐧! 𝐓𝐡𝐞 𝐰𝐨𝐫𝐝 𝐢𝐬 : ${maskedWord}` });
}

function guessLetter(sock, chatId, letter) {
    if (!hangmanGames[chatId]) {
        sock.sendMessage(chatId, { text: '*𝐒𝐭𝐚𝐫𝐭 𝐚 𝐧𝐞𝐰 𝐆𝐚𝐦𝐞 𝐰𝐢𝐭𝐡* .hangman' });
        return;
    }

    const game = hangmanGames[chatId];
    const { word, guessedLetters, maskedWord, maxWrongGuesses } = game;

    if (guessedLetters.includes(letter)) {
        sock.sendMessage(chatId, { text: `You already guessed "${letter}". Try another letter.` });
        return;
    }

    guessedLetters.push(letter);

    if (word.includes(letter)) {
        for (let i = 0; i < word.length; i++) {
            if (word[i] === letter) {
                maskedWord[i] = letter;
            }
        }
        sock.sendMessage(chatId, { text: `Good guess! ${maskedWord.join(' ')}` });

        if (!maskedWord.includes('_')) {
            sock.sendMessage(chatId, { text: `𝐂𝐨𝐧𝐠𝐫𝐚𝐭𝐮𝐥𝐚𝐭𝐢𝐨𝐧𝐬! 𝐘𝐨𝐮 𝐟𝐨𝐮𝐧𝐝 𝐭𝐡𝐢𝐬 𝐰𝐨𝐫𝐝: ${word}` });
            delete hangmanGames[chatId];
        }
    } else {
        game.wrongGuesses += 1;
        sock.sendMessage(chatId, { text: `𝐖𝐫𝐨𝐧𝐡! 𝐘𝐨𝐮 𝐡𝐚𝐯𝐞 ${maxWrongGuesses - game.wrongGuesses} 𝐂𝐡𝐚𝐧𝐜𝐞𝐬 𝐥𝐞𝐟𝐭.` });

        if (game.wrongGuesses >= maxWrongGuesses) {
            sock.sendMessage(chatId, { text: `𝐆𝐚𝐦𝐞 𝐨𝐯𝐞𝐫! 𝐓𝐡𝐞 𝐰𝐨𝐫𝐝 𝐰𝐚𝐬: ${word}` });
            delete hangmanGames[chatId];
        }
    }
}

module.exports = { startHangman, guessLetter };
