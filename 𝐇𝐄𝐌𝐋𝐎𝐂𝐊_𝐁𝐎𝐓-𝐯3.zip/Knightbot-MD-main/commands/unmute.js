async function unmuteCommand(sock, chatId) {
    await sock.groupSettingUpdate(chatId, 'not_announcement'); // Unmute the group
    await sock.sendMessage(chatId, { text: '𝐓𝐡𝐞 𝐆𝐫𝐨𝐮𝐩 𝐢𝐬 𝐛𝐚𝐜𝐤 𝐍𝐨𝐰 𝐲𝐨𝐮 𝐜𝐚𝐧 𝐭𝐞𝐱𝐭 𝐚𝐧𝐲 𝐦𝐞𝐬𝐬𝐚𝐠𝐞 𝐡𝐞𝐫𝐞. 𝐑𝐄𝐌𝐈𝐍𝐃𝐄𝐑:𝐍𝐨 𝐥𝐢𝐧𝐤𝐬 𝐚𝐥𝐥𝐨𝐰𝐞𝐝🖇️🚫' });
}

module.exports = unmuteCommand;
