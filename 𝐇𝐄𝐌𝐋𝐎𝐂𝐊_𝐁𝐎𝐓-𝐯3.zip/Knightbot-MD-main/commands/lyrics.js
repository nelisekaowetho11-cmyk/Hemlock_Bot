const fetch = require('node-fetch');

async function lyricsCommand(sock, chatId, songTitle, message) {
    if (!songTitle) {
        await sock.sendMessage(chatId, { 
            text: '🔍 𝐄𝐧𝐭𝐞𝐫 𝐭𝐡𝐞 𝐬𝐨𝐧𝐠 𝐧𝐚𝐦𝐞 𝐜𝐨𝐫𝐫𝐞𝐜𝐭𝐥𝐲 𝐭𝐨 𝐠𝐞𝐭 𝐥𝐲𝐫𝐢𝐜𝐬! 𝐄𝐱𝐚𝐩𝐥𝐞: *lyrics <song name>*'
        },{ quoted: message });
        return;
    }

    try {
        // Use lyricsapi.fly.dev and return only the raw lyrics text
        const apiUrl = `https://lyricsapi.fly.dev/api/lyrics?q=${encodeURIComponent(songTitle)}`;
        const res = await fetch(apiUrl);
        
        if (!res.ok) {
            const errText = await res.text();
            throw errText;
        }
        
        const data = await res.json();

        const lyrics = data && data.result && data.result.lyrics ? data.result.lyrics : null;
        if (!lyrics) {
            await sock.sendMessage(chatId, {
                text: `❌ *𝐒𝐨𝐫𝐫𝐲 𝐢 𝐝𝐨𝐧'𝐭 𝐡𝐚𝐯𝐞 𝐥𝐲𝐫𝐢𝐜𝐬 𝐟𝐨𝐫 𝐭𝐡𝐢𝐬 𝐬𝐨𝐧𝐠* "${songTitle}".`
            },{ quoted: message });
            return;
        }

        const maxChars = 4096;
        const output = lyrics.length > maxChars ? lyrics.slice(0, maxChars - 3) + '...' : lyrics;

        await sock.sendMessage(chatId, { text: output }, { quoted: message });
    } catch (error) {
        console.error('Error in lyrics command:', error);
        await sock.sendMessage(chatId, { 
            text: `❌ *𝐒𝐨𝐦𝐞𝐭𝐡𝐢𝐧𝐠 𝐰𝐫𝐨𝐧𝐠 𝐡𝐚𝐩𝐩𝐞𝐧𝐝 𝐰𝐡𝐢𝐥𝐞 𝐟𝐞𝐭𝐜𝐡𝐢𝐧𝐠 𝐭𝐡𝐞 𝐥𝐲𝐫𝐢𝐜𝐬 𝐟𝐨𝐫 "${songTitle}".`
        },{ quoted: message });
    }
}

module.exports = { lyricsCommand };
