const isAdmin = require('../lib/isAdmin');

async function muteCommand(sock, chatId, senderId, message, durationInMinutes) {
    

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
    if (!isBotAdmin) {
        await sock.sendMessage(chatId, { text: 'Please make the bot an admin first.' }, { quoted: message });
        return;
    }

    if (!isSenderAdmin) {
        await sock.sendMessage(chatId, { text: 'Only group admins can use the mute command.' }, { quoted: message });
        return;
    }

    try {
        // Mute the group
        await sock.groupSettingUpdate(chatId, 'announcement');
        
        if (durationInMinutes !== undefined && durationInMinutes > 0) {
            const durationInMilliseconds = durationInMinutes * 60 * 1000;
            await sock.sendMessage(chatId, { text: `*𝐓𝐡𝐞 𝐆𝐫𝐨𝐮𝐩 𝐢𝐬 𝐢𝐧 𝐌𝐚𝐢𝐧𝐭𝐞𝐧𝐚𝐧𝐜𝐞 𝐚𝐧𝐝 𝐢𝐭 𝐢𝐬 𝐦𝐮𝐭𝐞𝐝 𝐟𝐨𝐫 ${durationInMinutes} 𝐌𝐢𝐧𝐮𝐭𝐞𝐬. 𝐖𝐞 𝐰𝐢𝐥𝐥 𝐨𝐩𝐞𝐧 𝐢𝐭 𝐚𝐬 𝐬𝐨𝐨𝐧 𝐚𝐬 𝐰𝐞 𝐜𝐚𝐧 𝐩𝐥𝐞𝐚𝐬𝐞 𝐛𝐞 𝐩𝐚𝐭𝐢𝐞𝐧𝐜𝐞🫡*` }, { quoted: message });
            
            // Set timeout to unmute after duration
            setTimeout(async () => {
                try {
                    await sock.groupSettingUpdate(chatId, 'not_announcement');
                    await sock.sendMessage(chatId, { text: '𝐓𝐡𝐞 𝐠𝐫𝐨𝐮𝐩 𝐢𝐬 𝐛𝐚𝐜𝐤 𝐆𝐮𝐲𝐬 𝐚𝐧𝐲𝐨𝐧𝐞 𝐜𝐚𝐧 𝐭𝐞𝐱𝐭😇.' });
                } catch (unmuteError) {
                    console.error('Error unmuting group:', unmuteError);
                }
            }, durationInMilliseconds);
        } else {
            await sock.sendMessage(chatId, { text: '𝐓𝐡𝐞 𝐆𝐫𝐨𝐮𝐩 𝐢𝐬 𝐧𝐨𝐰 𝐦𝐮𝐭𝐞𝐝 𝐰𝐞 𝐰𝐢𝐥𝐥 𝐨𝐩𝐞𝐧 𝐢𝐭 𝐚𝐬 𝐬𝐨𝐨𝐧 𝐚𝐬 𝐰𝐞 𝐜𝐚𝐧.' }, { quoted: message });
        }
    } catch (error) {
        console.error('Error muting/unmuting the group:', error);
        await sock.sendMessage(chatId, { text: '*Something wrong happened while muting/unmuting the group. Please try again.*' }, { quoted: message });
    }
}

module.exports = muteCommand;
