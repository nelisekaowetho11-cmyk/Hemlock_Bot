const axios = require('axios');

module.exports = async function (sock, chatId) {
    try {
        const response = await axios.get('https://icanhazdadjoke.com/', {
            headers: { Accept: 'application/json' }
        });
        const joke = response.data.joke;
        await sock.sendMessage(chatId, { text: joke });
    } catch (error) {
        console.error('Error fetching joke:', error);
        await sock.sendMessage(chatId, { text: '*𝐄𝐢𝐬𝐡 𝐬𝐨𝐫𝐫𝐲 𝐢 𝐝𝐨 𝐧𝐨𝐭 𝐡𝐚𝐯𝐞 𝐣𝐨𝐤𝐞𝐬*.' });
    }
};
