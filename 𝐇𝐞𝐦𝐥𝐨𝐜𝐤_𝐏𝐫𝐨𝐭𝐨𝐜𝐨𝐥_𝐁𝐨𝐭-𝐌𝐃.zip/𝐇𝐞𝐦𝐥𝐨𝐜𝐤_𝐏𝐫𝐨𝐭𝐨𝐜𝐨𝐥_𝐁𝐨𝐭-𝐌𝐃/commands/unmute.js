async function unmuteCommand(sock, chatId) {
    await sock.groupSettingUpdate(chatId, 'not_announcement'); // Unmute the group
    await sock.sendMessage(chatId, { text: '𝐓𝐇𝐄 𝐆𝐑𝐎𝐔𝐏 𝐈𝐒 𝐎𝐏𝐄𝐍𝐄𝐃 𝐀𝐍𝐘𝐎𝐍𝐄 𝐂𝐀𝐍 𝐒𝐄𝐍𝐃 𝐌𝐄𝐒𝐒𝐀𝐆𝐄𝐒' });
}

module.exports = unmuteCommand;
