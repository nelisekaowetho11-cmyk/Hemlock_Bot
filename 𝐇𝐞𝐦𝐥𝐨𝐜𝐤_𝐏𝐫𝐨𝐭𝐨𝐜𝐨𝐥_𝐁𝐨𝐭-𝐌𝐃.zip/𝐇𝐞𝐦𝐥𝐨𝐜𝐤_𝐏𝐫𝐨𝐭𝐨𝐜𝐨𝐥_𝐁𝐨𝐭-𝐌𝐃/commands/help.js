const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
╔═══════════════════╗
   *🤖 ${settings.botName || '𝐇𝐄𝐌𝐋𝐎𝐂𝐊_𝐁𝐎𝐓'}*  
   Version: *${settings.version || '3.0.0'}*
   by ${settings.botOwner || '𝐌𝐑 𝐇𝐄𝐌𝐋𝐎𝐂𝐊_𝐏𝐑𝐎𝐓𝐎𝐂𝐎𝐋'}
   YT : ${global.ytch}
╚═══════════════════╝

*𝐁𝐎𝐓 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒:*

╔═══════════════════╗
🌐 *𝐆𝐞𝐧𝐞𝐫𝐚𝐥 𝐂𝐨𝐦𝐦𝐚𝐦𝐝𝐬*:
║ ➀ .help or .menu
║ ➁ .ping
║ ➂ .alive
║ ➃ .tts <text>
║ ➄ .owner
║ ➅ .joke
║ ➆ .quote
║ ➇ .fact
║ ➈ .weather <city>
║ ➉ .news
║ ⑪ .attp <text>
║ ⑫ .lyrics <song_title>
║ ⑬ .8ball <question>
║ ⑭ .groupinfo
║ ⑮ .staff or .admins 
║ ⑯ .vv
║ ⑰ .trt <text> <lang>
║ ⑱ .ss <link>
║ ⑲ .jid
║ ⑳ .url
╚═══════════════════╝ 

╔═══════════════════╗
👮‍♂️ *𝐀𝐝𝐦𝐢𝐧 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬*:
║ ➀ .ban @user
║ ➁ .promote @user
║ ➂ .demote @user
║ ➃ .mute <minutes>
║ ➄ .unmute
║ ➅ .delete or .del
║ ➆ .kick @user
║ ➇ .warnings @user
║ ➈ .warn @user
║ ➉ .antilink
║ ⑪ .antibadword
║ ⑫ .clear
║ ⑬ .tag <message>
║ ⑭ .tagall
║ ⑮ .tagnotadmin
║ ⑯ .hidetag <message>
║ ⑰ .chatbot
║ ⑱ .resetlink
║ ⑲ .antitag <on/off>
║ ⑳ .welcome <on/off>
║ ㉑ .goodbye <on/off>
║ ㉒ .setgdesc <description>
║ ㉓ .setgname <new name>
║ ㉔ .setgpp (reply to image)
╚═══════════════════╝

╔═══════════════════╗
🔒 *𝐎𝐰𝐧𝐞𝐫 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬*:
║ ➀ .mode <public/private>
║ ➁ .clearsession
║ ➂ .antidelete
║ ➃ .cleartmp
║ ➄ .update
║ ➅ .settings
║ ➆ .setpp <reply to image>
║ ➇ .autoreact <on/off>
║ ➈ .autostatus <on/off>
║ ➉ .autostatus react <on/off>
║ ⑪ .autotyping <on/off>
║ ⑫ .autoread <on/off>
║ ⑬ .anticall <on/off>
║ ⑭ .pmblocker <on/off/status>
║ ⑮ .pmblocker setmsg <text>
║ ⑯ .setmention <reply to msg>
║ ⑰ .mention <on/off>
╚═══════════════════╝

╔═══════════════════╗
🎨 *𝐈𝐦𝐚𝐠𝐞/𝐒𝐭𝐢𝐜𝐤𝐞𝐫 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬*:
║ ➀ .blur <image>
║ ➁ .simage <reply to sticker>
║ ➂ .sticker <reply to image>
║ ➃ .removebg
║ ➄ .remini
║ ➅ .crop <reply to image>
║ ➆ .tgsticker <Link>
║ ➇ .meme
║ ➈ .take <packname> 
║ ➉ .emojimix <emj1>+<emj2>
║ ⑪ .igs <insta link>
║ ⑫ .igsc <insta link>
╚═══════════════════╝  

╔═══════════════════╗
🖼️ *𝐏𝐢𝐞𝐬 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬*:
║ ➀ .pies <country>
║ ➁ .china 
║ ➂ .indonesia 
║ ➃ .japan 
║ ➄ .korea 
║ ➅ .hijab
╚═══════════════════╝

╔═══════════════════╗
🎮 *𝐆𝐚𝐦𝐞 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬*:
║ ➀ .tictactoe @user
║ ➁ .hangman
║ ➂ .guess <letter>
║ ➃ .trivia
║ ➄ .answer <answer>
║ ➅ .truth
║ ➆ .dare
╚═══════════════════╝

╔═══════════════════╗
🤖 *𝐀𝐈 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬*:
║ ➀ .gpt <question>
║ ➁ .gemini <question>
║ ➂ .imagine <prompt>
║ ➃ .flux <prompt>
║ ➄ .sora <prompt>
╚═══════════════════╝

╔═══════════════════╗
🎯 *𝐅𝐮𝐧 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬*:
║ ➀ .compliment @user
║ ➁ .insult @user
║ ➂ .flirt 
║ ➃ .shayari
║ ➄ .goodnight
║ ➅ .roseday
║ ➆ .character @user
║ ➇ .wasted @user
║ ➈ .ship @user
║ ➉ .simp @user
║ ⑪ .stupid @user [text]
╚═══════════════════╝

╔═══════════════════╗
🔤 *𝐓𝐞𝐱𝐭 𝐌𝐚𝐤𝐞𝐫*:
║ ➀ .metallic <text>
║ ➁ .ice <text>
║ ➂ .snow <text>
║ ➃ .impressive <text>
║ ➄ .matrix <text>
║ ➅ .light <text>
║ ➆ .neon <text>
║ ➇ .devil <text>
║ ➈ .purple <text>
║ ➉ .thunder <text>
║ ⑪ .leaves <text>
║ ⑫ .1917 <text>
║ ⑬ .arena <text>
║ ⑭ .hacker <text>
║ ⑮ .sand <text>
║ ⑯ .blackpink <text>
║ ⑰ .glitch <text>
║ ⑱ .fire <text>
╚═══════════════════╝

╔═══════════════════╗
📥 *𝐃𝐨𝐰𝐧𝐥𝐨𝐚𝐝𝐞𝐫*:
║ ➀ .play <song_name>
║ ➁ .song <song_name>
║ ➂ .spotify <query>
║ ➃ .instagram <link>
║ ➄ .facebook <link>
║ ➅ .tiktok <link>
║ ➆ .video <song name>
║ ➇ .ytmp4 <Link>
╚═══════════════════╝

╔═══════════════════╗
🧩 *𝐌𝐈𝐒𝐂*:
║ ➀ .heart
║ ➁ .horny
║ ➂ .circle
║ ➃ .lgbt
║ ➄ .lolice
║ ➅ .its-so-stupid
║ ➆ .namecard 
║ ➇ .oogway
║ ➈ .tweet
║ ➉ .ytcomment 
║ ⑪ .comrade 
║ ⑫ .gay 
║ ⑬ .glass 
║ ⑭ .jail 
║ ⑮ .passed 
║ ⑯ .triggered
╚═══════════════════╝

╔═══════════════════╗
🖼️ *𝐀𝐍𝐈𝐌𝐄*:
║ ➀ .nom 
║ ➁ .poke 
║ ➂ .cry 
║ ➃ .kiss 
║ ➄ .pat 
║ ➅ .hug 
║ ➆ .wink 
║ ➇ .facepalm 
╚═══════════════════╝

╔═══════════════════╗
💻 *𝐆𝐢𝐭𝐡𝐮𝐛 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬*
║ ➀ .git
║ ➁ .github
║ ➂ .sc
║ ➃ .script
║ ➄ .repo
╚═══════════════════╝

𝐉𝐨𝐢𝐧 𝐌𝐲 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 𝐂𝐡𝐚𝐧𝐧𝐞𝐥⬇️
https://whatsapp.com/channel/0029Vb9R1yF42Dcf0go2yW0x`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363431093344314@newsletter',
                        newsletterName: 'GHOSTGRAVE MD',
                        serverMessageId: -1
                    }
                }
            },{ quoted: message });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363431093344314@newsletter',
                        newsletterName: 'GHOSTGRAVE MD',
                        serverMessageId: -1
                    } 
                }
            });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;