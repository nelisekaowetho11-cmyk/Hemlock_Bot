const { handleWelcome } = require('../lib/welcome');
const { isWelcomeOn, getWelcome } = require('../lib/index');
const { channelInfo } = require('../lib/messageConfig');
const fetch = require('node-fetch');

async function welcomeCommand(sock, chatId, message, match) {
    // Check if it's a group
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: '*This command can only be used in groups*.' });
        return;
    }

    // Extract match from message
    const text = message.message?.conversation || 
                message.message?.extendedTextMessage?.text || '';
    const matchText = text.split(' ').slice(1).join(' ');

    await handleWelcome(sock, chatId, message, matchText);
}

async function handleJoinEvent(sock, id, participants) {
    // Check if welcome is enabled for this group
    const isWelcomeEnabled = await isWelcomeOn(id);
    if (!isWelcomeEnabled) return;

    // Get custom welcome message
    const customMessage = await getWelcome(id);

    // Get group metadata
    const groupMetadata = await sock.groupMetadata(id);
    const groupName = groupMetadata.subject;
    const groupDesc = groupMetadata.desc || '*No description available*';

    // Send welcome message for each new participant
    for (const participant of participants) {
        try {
            // Handle case where participant might be an object or not a string
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];
            
            // Get user's display name
            let displayName = user; // Default to phone number
            try {
                const contact = await sock.getBusinessProfile(participantString);
                if (contact && contact.name) {
                    displayName = contact.name;
                } else {
                    // Try to get from group participants
                    const groupParticipants = groupMetadata.participants;
                    const userParticipant = groupParticipants.find(p => p.id === participantString);
                    if (userParticipant && userParticipant.name) {
                        displayName = userParticipant.name;
                    }
                }
            } catch (nameError) {
                console.log('Could not fetch display name, using phone number');
            }
            
            // Process custom message with variables
            let finalMessage;
            if (customMessage) {
                finalMessage = customMessage
                    .replace(/{user}/g, `@${displayName}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc);
            } else {
                // Default message if no custom message is set
                const now = new Date();
                const timeString = now.toLocaleString('en-US', {
                    month: '2-digit',
                    day: '2-digit', 
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true
                });
                
                finalMessage = `╭╼━≪•𝐍𝐄𝐖 𝐌𝐄𝐌𝐁𝐄𝐑•≫━╾╮\n┃𝚆𝙴𝙻𝙲𝙾𝙼𝙴: @${displayName} 👋\n┃Member count: #${groupMetadata.participants.length}\n┃𝚃𝙸𝙼𝙴: ${timeString}⏰\n╰━━━━━━━━━━━━━━━╯\n\n*@${displayName}* Welcome to *${groupName}*! 🎉\n*Group 𝙳𝙴𝚂𝙲𝚁𝙸𝙿𝚃𝙸𝙾𝙽*\n${groupDesc}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ 𝐇𝐞𝐦𝐥𝐨𝐜𝐤_𝐁𝐨𝐭*`;
            }
            
            // Try to send with image first (always try images)
            try {
                // Get user profile picture
                let profilePicUrl = `https://img.pyrocdn.com/dbKUgahg.png`; // Default avatar
                try {
                    const profilePic = await sock.profilePictureUrl(participantString, 'image');
                    if (profilePic) {
                        profilePicUrl = profilePic;
                    }
                } catch (profileError) {
                    console.log('Could not fetch profile picture, using default');
                }
                
                // Construct API URL for welcome image
                const apiUrl = `https://api.siputzx.my.id/api/canvas/welcomev2?avatar=${encodeURIComponent(profilePicUrl)}&background=${encodeURIComponent('https://i.imgur.com/4yaqZ5u.jpeg')}&title=WELCOME&name=${encodeURIComponent(displayName)}&memberCount=${groupMetadata.participants.length}&description=${encodeURIComponent('Welcome to ' + groupName)}`;
                
                // Fetch the welcome image
                const response = await fetch(apiUrl);
                if (response.ok) {
                    const imageBuffer = await response.buffer();
                    
                    // Send welcome image with caption (custom or default message)
                    await sock.sendMessage(id, {
                        image: imageBuffer,
                        caption: finalMessage,
                        mentions: [participantString],
                        ...channelInfo
                    });
                    continue; // Skip to next participant
                }
            } catch (imageError) {
                console.log('Image generation failed, falling back to text');
            }
            
            // Send text message (either custom message or fallback)
            await sock.sendMessage(id, {
                text: finalMessage,
                mentions: [participantString],
                ...channelInfo
            });
        } catch (error) {
            console.error('Error sending welcome message:', error);
            // Fallback to text message
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];
            
            // Use custom message if available, otherwise use simple fallback
            let fallbackMessage;
            if (customMessage) {
                fallbackMessage = customMessage
                    .replace(/{user}/g, `@${user}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc);
            } else {
                fallbackMessage = `Welcome @${user} to ${groupName}! 📌 *GROUP RULES:*
*🚀 FREE NET GROUP RULES 🚀*

*1. NO PORN / NUDES*
Post 18+ = instant ban.

*2. NO SCAMMING / SELLING*💵
No scamming people here be serios and trustfully

*3. NO SPAMMING*🙅‍♂️
No flooding stickers or same file x10.

*4. RESPECT EVERYONE*🫡
No insults, no fighting. Help each other.

*5. DON'T INBOX ADMINS*📥
Ask in group, not in DM.

*6. NO GROUP LINKS*🖇️
No WhatsApp/Telegram links without permission.

*7. NO FAKE / EXPIRED CONFIGS*📁
Test before post. Include: Network | App | Expiry

*8. NO PERSONAL INFO*🧑‍🦱
Don't share numbers/passwords.

*9. STAY ON TOPIC*🎩
Only Freenet, Hosts, VPN, Configs.

*10. NO BEGGING*🙏
Search old messages first. Don't say "DM me".

*HOW TO POST:*
Network | App | Expiry | Status
Example: MTN ZA | HTTP Custom | 25 Oct | Working

⚠️ 𝐈𝐟 𝐲𝐨𝐮 𝐛𝐫𝐞𝐚𝐤 𝐭𝐡𝐨𝐬𝐞 𝐑𝐔𝐋𝐄𝐒 𝐚𝐛𝐨𝐯𝐞 𝐲𝐨𝐮 𝐰𝐢𝐥𝐥 𝐛𝐞 𝐑𝐄𝐌𝐎𝐕𝐄𝐃!

🔗 𝐅𝐨𝐥𝐥𝐨𝐰 𝐌𝐲 𝐜𝐡𝐚𝐧𝐧𝐞𝐥:⬇️
https://whatsapp.com/channel/0029Vb9R1yF42Dcf0go2yW0x
> 𝐏𝐫𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐇𝐞𝐦𝐥𝐨𝐜𝐤_𝐏𝐫𝐨𝐭𝐨𝐜𝐨𝐥👨‍💻`;
            }
            
            await sock.sendMessage(id, {
                text: fallbackMessage,
                mentions: [participantString],
                ...channelInfo
            });
        }
    }
}

module.exports = { welcomeCommand, handleJoinEvent };
